// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.content.ComponentName;
import android.os.IBinder;

// Referenced classes of package android.support.v4.app:
//            NotificationManagerCompat

private static class iBinder
{

    final ComponentName componentName;
    final IBinder iBinder;

    public (ComponentName componentname, IBinder ibinder)
    {
        componentName = componentname;
        iBinder = ibinder;
    }
}
